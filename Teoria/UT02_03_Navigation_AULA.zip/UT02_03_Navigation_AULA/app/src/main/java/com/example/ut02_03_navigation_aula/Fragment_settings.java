package com.example.ut02_03_navigation_aula;

import android.os.Bundle;

import androidx.preference.PreferenceFragmentCompat;

public class Fragment_settings extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey);
    }
}