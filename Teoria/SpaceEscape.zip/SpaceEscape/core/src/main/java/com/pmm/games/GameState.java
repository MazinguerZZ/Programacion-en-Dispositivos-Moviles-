package com.pmm.games;

public enum GameState {
    MENU,
    PLAYING,
    GAME_OVER
}
