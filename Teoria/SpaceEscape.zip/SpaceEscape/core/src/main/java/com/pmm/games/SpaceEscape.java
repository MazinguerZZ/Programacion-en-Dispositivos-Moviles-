package com.pmm.games;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.pmm.games.objects.Obstacle;
import com.pmm.games.objects.Player;

import java.lang.ref.PhantomReference;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class SpaceEscape extends ApplicationAdapter {

    private SpriteBatch batch;
    private Texture image;
    private BitmapFont font;

    // ESTADOS
    private GameState gameState, nextGameState;
    private Texture gameLogo;
    private  boolean gameStateChanged;

    // OBJETOS
    private Player player;
    private Array<Obstacle> obstacles;
    private Texture obstacleTexture;
    private float spawnTimer;

    @Override
    public void create() {
        batch = new SpriteBatch();
        image = new Texture("libgdx.png");
        font = new BitmapFont();

        gameLogo = new Texture("images/minecraft.jpg");
        gameState = GameState.MENU;
        gameStateChanged = false;

        Texture playerTexture = new Texture("images/angryBird.jpg");
        float x = (Gdx.graphics.getWidth() -  64) / 2.0f;
        player = new Player(playerTexture, x, 50, 64, 64, 5f);

        // Inicializamos los asteroides
        obstacles = new Array<>();
        obstacleTexture = new Texture("images/cerdo.png");
        spawnTimer = 0;

    }

    @Override
    public void render() {
        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);

        actualizarObjetos();

        gestionarInputs();

        batch.begin();

        representacionEstado();

        if (gameStateChanged) {
            if (nextGameState == GameState.MENU && gameState==GameState.GAME_OVER) {
                obstacles.clear();
            }

            gameState = nextGameState;
            gameStateChanged = false;
        }
        batch.end();

    }

    private void gestionarInputs() {
        switch (gameState) {
            case MENU:

                if (Gdx.input.isTouched()) {
                    nextGameState = GameState.PLAYING;
                    gameStateChanged = true;
                }


                    if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
                    nextGameState = GameState.PLAYING;
                    gameStateChanged = true;
                }

                break;
            case PLAYING:

                if (Gdx.input.isTouched()){
                    float deltaX = Gdx.input.getDeltaX() - player.getX();
                    if (deltaX > 0) player.moveRight();
                    else if (deltaX < 0) player.moveLeft();
                    float deltaY = Gdx.input.getDeltaY() - player.getY();
                    if (deltaY > 0) player.moveDown();
                    else if (deltaY < 0) player.moveUp();
                }

                if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
                    player.moveLeft();
                }
                if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
                    player.moveRight();
                }
                if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
                    player.moveUp();
                }
                if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
                    player.moveDown();
                }
                break;

            case GAME_OVER:
                if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {
                    nextGameState = GameState.MENU;
                    gameStateChanged = true;
                }
                break;
        }
    }

    private void actualizarObjetos() {

        float deltaTime = Gdx.graphics.getDeltaTime();
        spawnTimer += deltaTime;
        if (spawnTimer >= 1.2f) {
            addObstacle();
            spawnTimer = 0;
        }

        for (int i = obstacles.size - 1; i >= 0; i--) {
            Obstacle obstacle = obstacles.get(i);
            obstacle.update();

            if (obstacle.isOutOfScreen()) {
                obstacles.removeIndex(i);
            }
        }
    }

    private void addObstacle() {
        float width = 48; // width = 48
        float height = 48; // height = 48

        float x = MathUtils.random(0,Gdx.graphics.getWidth()-width);
        float y = Gdx.graphics.getHeight();

        obstacles.add(new Obstacle(obstacleTexture, x, y, width, height, 3f));
    }

    private void representacionEstado() {

        int screenWidth = Gdx.graphics.getWidth();
        int screenHight = Gdx.graphics.getHeight();

        switch (gameState) {
            case MENU:
                batch.draw(gameLogo, 0, 0, screenWidth, screenHight);
                font.draw(batch, "Pulsa ESPACIO para comenzar", 100, 100);

                break;
            case PLAYING:
                ScreenUtils.clear(Color.BLACK);
                batch.draw(image, 140, 210);
                font.setColor(Color.WHITE);
                font.draw(batch, "Pulsa ESC para terminar", 10, screenHight-10);
                font.setColor(Color.RED);
                font.draw(batch,"Jugando...", (float)(screenWidth*0.45), 100);

                player.render(batch);
                for (int i = obstacles.size - 1; i >= 0; i--) {
                    Obstacle obstacle = obstacles.get(i);
                    obstacle.render(batch);
                }


                for (Obstacle obstacle : obstacles) {
                    if (obstacle.getBounds().overlaps(player.getBounds())){
                        gameState = GameState.GAME_OVER;
                        gameStateChanged = false;
                        break;
                    }
                }
                break;

            case GAME_OVER:
                ScreenUtils.clear(Color.RED);
                font.draw(batch, "GAME OVER", 100, 150);
                font.draw(batch, "Pulsa Enter para volver a jugar", 100, 100);
                break;
        }
    }

    @Override
    public void dispose() {
        batch.dispose();
        image.dispose();
        font.dispose();
        player.dipose();
        obstacleTexture.dispose();
    }
}
