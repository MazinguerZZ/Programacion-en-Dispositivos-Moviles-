package com.pmm.a23.net;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class HttpUtils {
    private static final String TAG = "HttpUtils";

    public static String getRequest(String urlString) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {
            // Crear URL
            URL url = new URL(urlString);

            // Abrir conexión
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000); // 5 segundos
            connection.setReadTimeout(5000); // 5 segundos
            connection.setRequestProperty("Accept", "application/json");

            // Verificar código de respuesta
            int responseCode = connection.getResponseCode();
            Log.d(TAG, "Response Code: " + responseCode);

            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Leer respuesta
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                Log.d(TAG, "Response: " + response.toString());
                return response.toString();
            } else {
                Log.e(TAG, "HTTP Error: " + responseCode);
                return null;
            }

        } catch (Exception e) {
            Log.e(TAG, "Error en la petición HTTP: " + e.getMessage(), e);
            return null;
        } finally {
            // Cerrar conexiones
            try {
                if (reader != null) reader.close();
                if (connection != null) connection.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Error cerrando recursos: " + e.getMessage());
            }
        }
    }

    // Método para parsear JSON específico de frases
    public static com.pmm.a23.data.Frase parseFraseFromJson(String jsonResponse) {
        try {
            // Este método debería ser implementado según el formato específico del servidor
            // Por ahora, creamos una frase de ejemplo
            if (jsonResponse != null && !jsonResponse.isEmpty()) {
                // Aquí deberías implementar el parsing real del JSON
                // Por ejemplo, usando JSONObject o Gson
                return new com.pmm.a23.data.Frase(
                        jsonResponse.substring(0, Math.min(50, jsonResponse.length())),
                        "Autor desde JSON"
                );
            }
        } catch (Exception e) {
            Log.e(TAG, "Error parseando JSON: " + e.getMessage());
        }
        return null;
    }
}



