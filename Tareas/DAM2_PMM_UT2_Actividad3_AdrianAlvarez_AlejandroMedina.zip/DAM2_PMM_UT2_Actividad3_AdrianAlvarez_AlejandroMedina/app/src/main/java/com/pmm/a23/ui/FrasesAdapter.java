package com.pmm.a23.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pmm.a23.R;
import com.pmm.a23.data.Frase;

import java.util.List;


public class FrasesAdapter extends RecyclerView.Adapter<FrasesAdapter.FraseViewHolder> {

    private List<Frase> frases;
    private static final String TAG = "FrasesAdapter";

    public FrasesAdapter() {
        this.frases = null;
    }

    public void setFrases(List<Frase> frases) {
        this.frases = frases;
        notifyDataSetChanged();
    }

    public void clearFrases() {
        if (frases != null) {
            frases.clear();
            notifyDataSetChanged();
        }
    }

    @NonNull
    @Override
    public FraseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_main, parent, false);
        return new FraseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FraseViewHolder holder, int position) {
        if (frases != null && position < frases.size()) {
            Frase frase = frases.get(position);
            holder.bind(frase);
        }
    }

    @Override
    public int getItemCount() {
        return frases != null ? frases.size() : 0;
    }

    static class FraseViewHolder extends RecyclerView.ViewHolder {
        private RecyclerView tvTexto;

        public FraseViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTexto = itemView.findViewById(R.id.frases);
        }

        public void bind(Frase frase) {
            tvTexto.setTextDirection(Integer.parseInt(frase.getTexto()));

        }
    }
}