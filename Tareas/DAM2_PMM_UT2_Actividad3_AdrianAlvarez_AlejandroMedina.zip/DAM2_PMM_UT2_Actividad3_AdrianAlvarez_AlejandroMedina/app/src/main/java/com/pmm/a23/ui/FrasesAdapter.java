package com.pmm.a23.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class FrasesAdapter extends RecyclerView.Adapter<FrasesAdapter.FraseViewHolder> {

    private ArrayList<String> frasesList;

    public FrasesAdapter(ArrayList<String> frasesList) {
        this.frasesList = frasesList;
    }

    @NonNull
    @Override
    public FraseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Usamos un layout simple de Android
        View view = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_1, parent, false);
        return new FraseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FraseViewHolder holder, int position) {
        String frase = frasesList.get(position);
        holder.textView.setText(frase);

        // Para que el texto se vea mejor
        holder.textView.setTextSize(16);
        holder.textView.setPadding(20, 20, 20, 20);
        holder.textView.setTextColor(holder.itemView.getResources().getColor(android.R.color.black));
    }

    @Override
    public int getItemCount() {
        return frasesList.size();
    }

    public static class FraseViewHolder extends RecyclerView.ViewHolder {
        TextView textView;

        public FraseViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(android.R.id.text1);
        }
    }
}