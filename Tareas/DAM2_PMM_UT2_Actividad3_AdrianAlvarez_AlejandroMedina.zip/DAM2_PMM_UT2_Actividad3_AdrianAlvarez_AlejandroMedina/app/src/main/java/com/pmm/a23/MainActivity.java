package com.pmm.a23;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.os.AsyncTask;

import com.pmm.a23.ui.FrasesAdapter;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<String> frasesList = new ArrayList<>();
    private FrasesAdapter adapter;
    private boolean mostrar = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar lista (opcional: agregar una frase de ejemplo)
        frasesList.add("\"La vida es lo que pasa mientras estás ocupado haciendo otros planes.\"\n- John Lennon");

        // Configurar RecyclerView
        recyclerView = findViewById(R.id.frases);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Crear y asignar adapter
        adapter = new FrasesAdapter(frasesList);
        recyclerView.setAdapter(adapter);

        // Ocultar al inicio
        recyclerView.setVisibility(View.GONE);
    }

    // Método para el botón Descarga Nueva Frase
    public void descargarFrase(View view) {
        new DescargarTarea().execute();
    }

    // Método para el botón Ocultar/Mostrar Frases
    public void ocultarFrases(View view) {
        if (mostrar) {
            recyclerView.setVisibility(View.GONE);
            mostrar = false;
        } else {
            if (frasesList.isEmpty()) {
                Toast.makeText(this, "No hay frases. Descarga una primero.", Toast.LENGTH_SHORT).show();
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                mostrar = true;
            }
        }
    }

    // Método para el botón Eliminar Frases
    public void eliminarFrase(View view) {
        frasesList.clear();
        adapter.notifyDataSetChanged();
        recyclerView.setVisibility(View.GONE);
        mostrar = false;
        Toast.makeText(this, "Todas las frases eliminadas", Toast.LENGTH_SHORT).show();
    }

    // Clase para descargar en segundo plano CON JSON PARSING MEJORADO
    private class DescargarTarea extends AsyncTask<Void, Void, String[]> {

        @Override
        protected String[] doInBackground(Void... voids) {
            try {
                URL url = new URL("https://zenquotes.io/api/random");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");
                conexion.setConnectTimeout(8000);
                conexion.setReadTimeout(8000);

                // Leer respuesta
                BufferedReader lector = new BufferedReader(
                        new InputStreamReader(conexion.getInputStream()));

                StringBuilder respuesta = new StringBuilder();
                String linea;
                while ((linea = lector.readLine()) != null) {
                    respuesta.append(linea);
                }
                lector.close();
                conexion.disconnect();

                String json = respuesta.toString();
                System.out.println("JSON recibido: " + json);

                // PARSEAR CON JSONObject (más seguro)
                JSONArray jsonArray = new JSONArray(json);
                if (jsonArray.length() > 0) {
                    JSONObject jsonObject = jsonArray.getJSONObject(0);

                    String frase = "";
                    String autor = "";

                    // Obtener frase (puede venir en diferentes campos)
                    if (jsonObject.has("q")) {
                        frase = jsonObject.getString("q");
                    } else if (jsonObject.has("quote")) {
                        frase = jsonObject.getString("quote");
                    } else if (jsonObject.has("text")) {
                        frase = jsonObject.getString("text");
                    }

                    // Obtener autor
                    if (jsonObject.has("a")) {
                        autor = jsonObject.getString("a");
                    } else if (jsonObject.has("author")) {
                        autor = jsonObject.getString("author");
                    }

                    // Limpiar la frase si es necesario
                    if (frase.contains("\\")) {
                        frase = frase.replace("\\", "");
                    }
                    if (frase.contains("\"")) {
                        frase = frase.replace("\"", "'");
                    }

                    return new String[]{frase, autor};
                }

            } catch (Exception e) {
                e.printStackTrace();
                // Si hay error de internet, usar frase de ejemplo
                String[] frasesEjemplo = {
                        "La vida es bella",
                        "El conocimiento es poder",
                        "Más vale tarde que nunca",
                        "Quien mucho abarca poco aprieta",
                        "No hay mal que por bien no venga",
                        "Al mal tiempo, buena cara",
                        "La práctica hace al maestro",
                        "Quien no arriesga no gana"
                };

                String[] autoresEjemplo = {
                        "Anónimo",
                        "Francis Bacon",
                        "Refrán popular",
                        "Refrán español",
                        "Refrán tradicional",
                        "Dicho popular",
                        "Proverbio",
                        "Sabiduría popular"
                };

                int indice = (int)(Math.random() * frasesEjemplo.length);
                return new String[]{frasesEjemplo[indice], autoresEjemplo[indice]};
            }
            return null;
        }

        @Override
        protected void onPostExecute(String[] resultado) {
            if (resultado != null && resultado.length == 2) {
                // Formatear la frase
                String fraseFormateada;
                if (resultado[0].startsWith("\"")) {
                    fraseFormateada = resultado[0] + "\n- " + resultado[1];
                } else {
                    fraseFormateada = "\"" + resultado[0] + "\"\n- " + resultado[1];
                }

                // Añadir a la lista
                frasesList.add(fraseFormateada);
                adapter.notifyItemInserted(frasesList.size() - 1);

                // Mostrar automáticamente si está oculto
                if (recyclerView.getVisibility() == View.GONE) {
                    recyclerView.setVisibility(View.VISIBLE);
                    mostrar = true;
                }

                // Desplazar hacia la última frase
                recyclerView.smoothScrollToPosition(frasesList.size() - 1);

                Toast.makeText(MainActivity.this,
                        "Frase añadida (" + frasesList.size() + " total)",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this,
                        "Error al descargar la frase",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}