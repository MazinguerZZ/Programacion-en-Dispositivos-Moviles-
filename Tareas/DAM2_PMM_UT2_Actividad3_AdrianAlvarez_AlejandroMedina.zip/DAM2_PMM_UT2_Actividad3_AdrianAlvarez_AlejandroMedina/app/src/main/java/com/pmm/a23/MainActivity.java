package com.pmm.a23;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.pmm.a23.ui.FrasesAdapter;
import com.pmm.a23.data.FrasesDAO;
import com.pmm.a23.data.Frase;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<String> frasesList;
    private FrasesAdapter adapter;
    private Button btnMostrarOcultar;
    private FrasesDAO frasesDAO;

    // Variable para saber si estamos mostrando u ocultando
    private boolean mostrarFrases = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar la lista de frases
        frasesList = new ArrayList<>();

        // Inicializar el DAO (para la base de datos)
        frasesDAO = new FrasesDAO(this);
        frasesDAO.open();

        // Referencia al botón
        btnMostrarOcultar = findViewById(R.id.btn2);

        // Configurar RecyclerView
        recyclerView = findViewById(R.id.frases);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Crear el adaptador
        adapter = new FrasesAdapter(frasesList);
        recyclerView.setAdapter(adapter);

        // Cargar frases de la base de datos al iniciar
        cargarFrasesDeBD();

        // Ocultar el RecyclerView al inicio
        recyclerView.setVisibility(View.GONE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Cerrar la base de datos
        frasesDAO.close();
    }

    private void cargarFrasesDeBD() {
        // Limpiar la lista actual
        frasesList.clear();

        // Obtener todas las frases de la base de datos
        List<Frase> frasesBD = frasesDAO.getAllFrases();

        // Convertir las frases a formato de texto para mostrar
        for (Frase frase : frasesBD) {
            String textoMostrar = "\"" + frase.getTexto() + "\"\n- " + frase.getAutor();
            frasesList.add(textoMostrar);
        }

        // Notificar al adaptador que los datos cambiaron
        adapter.notifyDataSetChanged();
    }

    // Método para el botón "Descargar Nueva Frase"
    public void descargarFrase(View view) {
        // Crear un hilo para la descarga (no bloquear la interfaz)
        new Thread(new Runnable() {
            @Override
            public void run() {
                // Descargar la frase de internet
                Frase nuevaFrase = descargarFraseDeInternet();

                // Volver al hilo principal para actualizar la interfaz
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (nuevaFrase != null) {
                            // Guardar en base de datos
                            long id = frasesDAO.insertFrase(nuevaFrase);

                            if (id != -1) {
                                // Añadir a la lista para mostrar
                                String textoMostrar = "\"" + nuevaFrase.getTexto() + "\"\n- " + nuevaFrase.getAutor();
                                frasesList.add(textoMostrar);
                                adapter.notifyItemInserted(frasesList.size() - 1);

                                Toast.makeText(MainActivity.this,
                                        "Frase añadida",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
            }
        }).start();
    }

    // Método para descargar de internet
    private Frase descargarFraseDeInternet() {
        try {
            // Usar HttpUtils que ya tienes
            String jsonResponse = com.pmm.a23.net.HttpUtils.getRequest("https://zenquotes.io/api/random");

            // VERIFICACIÓN CRÍTICA PARA EVITAR EXCEPCIONES
            if (jsonResponse != null && !jsonResponse.trim().isEmpty()) {
                try {
                    // Parsear el JSON con validación
                    org.json.JSONArray jsonArray = new org.json.JSONArray(jsonResponse);
                    if (jsonArray.length() > 0) {
                        org.json.JSONObject jsonObject = jsonArray.getJSONObject(0);

                        String texto = "";
                        String autor = "";

                        // Obtener texto con validación de campos
                        if (jsonObject.has("q")) {
                            texto = jsonObject.getString("q");
                        } else if (jsonObject.has("quote")) {
                            texto = jsonObject.getString("quote");
                        }

                        // Obtener autor con validación de campos
                        if (jsonObject.has("a")) {
                            autor = jsonObject.getString("a");
                        } else if (jsonObject.has("author")) {
                            autor = jsonObject.getString("author");
                        }

                        // Validar que tenemos datos
                        if (!texto.isEmpty() && !autor.isEmpty()) {
                            // Limpiar texto si es necesario
                            if (texto.contains("\"")) {
                                texto = texto.replace("\"", "'");
                            }

                            // Crear objeto Frase
                            Frase frase = new Frase();
                            frase.setTexto(texto);
                            frase.setAutor(autor);
                            return frase;
                        }
                    }
                } catch (org.json.JSONException e) {
                    e.printStackTrace();
                    // JSON inválido, usar frase de ejemplo
                    return crearFraseEjemplo();
                }
            }

            // Si llegamos aquí, hay algún problema
            return crearFraseEjemplo();

        } catch (Exception e) {
            e.printStackTrace();
            return crearFraseEjemplo();
        }
    }

    private Frase crearFraseEjemplo() {
        try {
            String[] frasesEjemplo = {
                    "La vida es bella - Aprovecha cada momento",
                    "El conocimiento es poder - Nunca dejes de aprender",
                    "Más vale tarde que nunca - Mejor intentarlo"
            };

            String[] autoresEjemplo = {
                    "Anónimo",
                    "Francis Bacon",
                    "Refrán popular"
            };

            int indice = (int)(Math.random() * frasesEjemplo.length);
            Frase frase = new Frase();
            frase.setTexto(frasesEjemplo[indice]);
            frase.setAutor(autoresEjemplo[indice]);
            return frase;
        } catch (Exception e) {
            // En caso extremo, devolver frase por defecto
            Frase frase = new Frase();
            frase.setTexto("La perseverancia es la clave del éxito");
            frase.setAutor("Anónimo");
            return frase;
        }
    }

    // Método para el botón "Mostrar/Ocultar Frases"
    public void ocultarFrases(View view) {
        if (mostrarFrases) {
            // Si está mostrando, lo ocultamos
            recyclerView.setVisibility(View.GONE);
            btnMostrarOcultar.setText("Mostrar Frases");
            mostrarFrases = false;
        } else {
            // Si está oculto, lo mostramos
            if (frasesList.isEmpty()) {
                Toast.makeText(this, "No hay frases para mostrar", Toast.LENGTH_SHORT).show();
            } else {
                // RECARGAR SIEMPRE DE LA BD (para tener las últimas)
                cargarFrasesDeBD();

                recyclerView.setVisibility(View.VISIBLE);
                btnMostrarOcultar.setText("Ocultar Frases");
                mostrarFrases = true;
            }
        }
    }

    // Método para el botón "Eliminar Frases"
    public void eliminarFrase(View view) {
        // Eliminar todas las frases de la base de datos
        int frasesEliminadas = frasesDAO.deleteAllFrases();

        // Limpiar la lista
        frasesList.clear();
        adapter.notifyDataSetChanged();

        // Ocultar el RecyclerView
        recyclerView.setVisibility(View.GONE);
        btnMostrarOcultar.setText("Mostrar Frases");
        mostrarFrases = false;

        // Mostrar mensaje
        Toast.makeText(this,
                "Se eliminaron " + frasesEliminadas + " frases",
                Toast.LENGTH_SHORT).show();
    }
}