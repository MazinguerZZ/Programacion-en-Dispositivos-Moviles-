package com.pmm.a23.data;

public class Frase {

    private String autorDesdeJson;
    private String substring;
    private int Id;
    private String titulo;
    private String autor;
    private String texto;


    public Frase (){}
    
    public Frase(String texto, String autor, String titulo, int id) {
        this.texto = texto;
        this.autor = autor;
        this.titulo = titulo;
        Id = id;
    }

    public Frase(String substring, String autorDesdeJson) {
        this.substring = substring;
        this.autorDesdeJson = autorDesdeJson;
    }


    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    @Override
    public String toString() {
        return "Frase{" +
                "Id=" + Id +
                ", titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", texto='" + texto + '\'' +
                '}';
    }
}
