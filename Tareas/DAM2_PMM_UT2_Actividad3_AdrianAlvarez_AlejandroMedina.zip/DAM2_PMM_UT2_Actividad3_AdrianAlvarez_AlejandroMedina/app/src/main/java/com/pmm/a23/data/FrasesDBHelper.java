package com.pmm.a23.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class FrasesDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "frases_motivadoras.db";
    private static final int DATABASE_VERSION = 1;

    // Nombres de tabla y columnas
    public static final String TABLE_FRASES = "frases";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TEXTO = "texto";
    public static final String COLUMN_AUTOR = "autor";
    public static final String COLUMN_TITULO = "titulo";

    // SQL para crear la tabla - SIN DATETIME DEFAULT CURRENT_TIMESTAMP
    private static final String CREATE_TABLE_FRASES =
            "CREATE TABLE " + TABLE_FRASES + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TEXTO + " TEXT NOT NULL, " +
                    COLUMN_AUTOR + " TEXT, " +
                    COLUMN_TITULO + " TEXT" +  // Simplemente TEXT, sin DEFAULT
                    ")";

    // SQL para eliminar tabla
    private static final String DROP_TABLE_FRASES =
            "DROP TABLE IF EXISTS " + TABLE_FRASES;

    public FrasesDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_FRASES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_TABLE_FRASES);
        onCreate(db);
    }
}