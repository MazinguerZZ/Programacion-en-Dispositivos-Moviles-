package com.pmm.a23.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FrasesDAO {

    private FrasesDBHelper dbHelper;
    private SQLiteDatabase database;
    private SimpleDateFormat dateFormat;

    public FrasesDAO(Context context) {
        dbHelper = new FrasesDBHelper(context);
        dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    // Insertar una nueva frase
    public long insertFrase(Frase frase) {
        ContentValues values = new ContentValues();
        values.put(FrasesDBHelper.COLUMN_TEXTO, frase.getTexto());
        values.put(FrasesDBHelper.COLUMN_AUTOR, frase.getAutor());

        // Añadir fecha actual como título (para que la columna no quede NULL)
        String fechaActual = dateFormat.format(new Date());
        values.put(FrasesDBHelper.COLUMN_TITULO, fechaActual);

        return database.insert(FrasesDBHelper.TABLE_FRASES, null, values);
    }

    // Obtener todas las frases ordenadas por fecha descendente
    public List<Frase> getAllFrases() {
        List<Frase> frases = new ArrayList<>();

        String[] columns = {
                FrasesDBHelper.COLUMN_ID,
                FrasesDBHelper.COLUMN_TEXTO,
                FrasesDBHelper.COLUMN_AUTOR,
                FrasesDBHelper.COLUMN_TITULO
        };

        String orderBy = FrasesDBHelper.COLUMN_ID + " DESC"; // Ordenar por ID descendente

        Cursor cursor = database.query(
                FrasesDBHelper.TABLE_FRASES,
                columns,
                null, null, null, null,
                orderBy
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                Frase frase = new Frase();
                frase.setId(cursor.getInt(cursor.getColumnIndexOrThrow(FrasesDBHelper.COLUMN_ID)));
                frase.setTexto(cursor.getString(cursor.getColumnIndexOrThrow(FrasesDBHelper.COLUMN_TEXTO)));
                frase.setAutor(cursor.getString(cursor.getColumnIndexOrThrow(FrasesDBHelper.COLUMN_AUTOR)));
                frase.setTitulo(cursor.getString(cursor.getColumnIndexOrThrow(FrasesDBHelper.COLUMN_TITULO)));

                frases.add(frase);
            } while (cursor.moveToNext());
            cursor.close();
        }

        return frases;
    }

    // Eliminar todas las frases
    public int deleteAllFrases() {
        return database.delete(FrasesDBHelper.TABLE_FRASES, null, null);
    }

    // Obtener el número total de frases
    public int getCount() {
        Cursor cursor = database.rawQuery(
                "SELECT COUNT(*) FROM " + FrasesDBHelper.TABLE_FRASES, null
        );

        int count = 0;
        if (cursor != null && cursor.moveToFirst()) {
            count = cursor.getInt(0);
            cursor.close();
        }

        return count;
    }
}