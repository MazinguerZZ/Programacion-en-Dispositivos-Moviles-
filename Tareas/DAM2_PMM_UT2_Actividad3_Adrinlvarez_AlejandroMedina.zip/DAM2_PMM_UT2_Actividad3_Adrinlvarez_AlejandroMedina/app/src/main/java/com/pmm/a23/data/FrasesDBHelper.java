package com.pmm.a23.data;

public class FrasesDBHelper {
}
