package com.pmm.a23.net;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class HttpUtils {

    private final String URL_JSON_POST = "https://zenquotes.io/api/random";



    private void sendPostRequest() {
        new Thread(() -> {
            BufferedReader reader = null;

            try {
                URL url = new URL(URL_JSON_POST);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                String jsonBody = "{ \"userId\": 99, \"id\": 1, \"title\": \"Nuevo título\", \"body\": \"Contenido del post\"}";

                conn.connect(); // Apertura explicita
                System.out.println("Conexión ABIERTA  con URL: " + URL_JSON_POST);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonBody.getBytes("UTF8");
                    os.write(input, 0, input.length);
                }

                int responseCode = conn.getResponseCode();


                if (responseCode == HttpURLConnection.HTTP_CREATED) {
                    System.out.println("Creación correcta del objeto por el servidor.");
                    reader = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                } else {
                    reader = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
                }

                StringBuilder response = new StringBuilder();
                String line;
                response.append("[");
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                response.append("]");


            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    reader.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();
    }

    private void sendGetRequest() {
        new Thread(() -> {
            List<Post> fetchedPosts = new ArrayList<>();
            BufferedReader reader = null;

            try {
                URL url = new URL(URL_JSON_POST);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                conn.connect();
                System.out.println("Conexión ABIERTA  con URL: " + URL_JSON_POST);

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    System.out.println("Conexión ESTABLECIDA OK.");

                    reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    JSONArray jsonArray = new JSONArray(response.toString());
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        Post post =  new Post(
                                obj.getInt("userId"),
                                obj.getInt("id"),
                                obj.getString("title"),
                                obj.getString("body")
                        );
                        fetchedPosts.add(post);
                    }
                }

                requireActivity().runOnUiThread(() -> adapter.setPost(fetchedPosts));


            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    reader.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();
    }

}
