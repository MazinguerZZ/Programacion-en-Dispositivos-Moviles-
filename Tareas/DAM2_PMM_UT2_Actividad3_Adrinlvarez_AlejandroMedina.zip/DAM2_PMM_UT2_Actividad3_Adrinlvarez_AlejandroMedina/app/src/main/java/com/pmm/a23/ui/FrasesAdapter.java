package com.pmm.a23.ui;

public class FrasesAdapter {
}
